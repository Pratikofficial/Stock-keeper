# StockKeeper v4.1.0 — Android Studio project

StockKeeper is an offline stock and invoice app. The dashboard contains Stock In, Stock Out and Cash Out cards, a **Balance** box, low-stock alerts, and a Cash Balance card with **Collected** and **Pending** amounts. Stock Out is a single invoice workspace with item search, quantities, prices, note, cash calculator, a read-only invoice and one save button. Saved invoices remain available through View invoices. The user-supplied purple chest image is the launcher icon, and the Android app label is `StockKeeper`.

## Balance box

Below the Stock Out card, the Balance box shows Invoice cash, Extra, Cash out and All Total:

* **Invoice cash** — all-time cash received from invoices, net of change, plus later payments net of reversals.
* **Extra** — change due that has not been returned yet. It is cash still in the drawer but owed to customers.
* **Cash out** — money recorded with the Cash Out button.
* **All Total** — Invoice cash + Extra − Cash out.

Currencies are listed separately and never converted. Invoices saved by earlier versions recorded change due but not whether it was handed back, so that change is left out of Extra until you review it: open **Review change** and choose *Still with me* or *Returned* for each invoice. New stock outs that include change due are counted as *Still with me* straight away. Change saved on a new invoice is also counted immediately. Reviewing change never edits an invoice; the original sale stays read-only. This total is not a bank balance.

## Cash out

Cash Out records money you spent and adds what you bought to stock. Choose the item from your saved inventory, enter the quantity, confirm the price, then Confirm. The result is a simple "Cash out Successfully" popup with no amount, the stock quantity goes up, and the record is saved in the Activity (Transactions) list, where the Cash out filter and CSV export include it. Every cash out is subtracted in the Balance box.

## Device permissions

The app still has no INTERNET permission and blocks network loads. The only permission it can ask for is **POST_NOTIFICATIONS** (Android 13+), used solely for the optional backup reminder in **Settings > Device permissions**. The app explains the purpose in its own dialog before the Android permission prompt appears. Storage permission is not requested: backups and CSV files are saved through the Android document picker, which needs none.

## Earlier pending invoice reference

In Stock Out, optionally search and select an earlier invoice with a known unpaid balance. The preview shows its current pending balance and latest active later payment if one exists. These amounts are shown for reference only: they are not added to the new sale total and the new sale's payment does not pay the old invoice. When the new invoice is saved, the displayed reference is a read-only snapshot as of that sale; later payments on the old invoice do not change it. To record a payment against the old invoice, open Pending Cash.

## Cash Balance

Collected is the all-time amount recorded at stock out, net of change, plus later payments net of reversals. Pending is the current total still owed on recorded invoices. Currencies are displayed separately; no conversion is performed. Invoices without usable payment details are excluded, and inconsistent sale-cash details are excluded from collected. This is not a cash-drawer or bank balance; expenses, withdrawals and deposits are not tracked.

## Updating from v4.0 or v4.1

This APK has the same app ID (`com.stockkeeper.app.v4`) and signing key as the supplied StockKeeper v4.0 and v4.1 Android APKs, with a higher Android version code. It is designed to update them in place and retain their data. Before installing, use **Settings > Export backup**. Install v4.1.0 without uninstalling the old version, open it, and verify your inventory, invoices, pending payments and the new Balance figures. Restore the backup only if necessary; restoring replaces current data. Do not uninstall the existing app before backing up.

When v4.1.0 first opens data written by v4.1, nothing is rewritten until you make a change. Change due on older invoices is not counted in Extra until you review it.

A build made independently in Android Studio will usually have a different debug signing key and therefore cannot update the supplied APK, even if its app ID is the same.

## Transfer from v3 or an earlier app

The older v3 test app (`com.stockkeeper.app.v3`) and v4.1.0 have different app IDs and separate local data. Export a JSON backup from the old app, install v4.1.0, then use Settings > Restore backup in the new app. Check items, transactions, invoices and pending balances before removing the old app. Earlier invoices with no recorded payment details are retained, but their unknown balances are excluded rather than assumed.

## Privacy and backups

The app has no INTERNET permission and blocks network loads. Data is stored locally in the app's WebView and is not synced. Export JSON backups regularly and before uninstalling or changing devices. Android's document picker is used for backup/restore and CSV export. The v4.1.0 backup includes payment and reversal history, prior-invoice reference snapshots, cash out records and change-due reviews. Use v4.1.0 or later to restore these backups.

## Build

Open this project in Android Studio with JDK 17+ and Android SDK 34, sync Gradle, then choose **Build > Build APK(s)**, or run `./gradlew assembleDebug`. Setup may require internet; the installed app works offline. The optional environment variable `STOCKKEEPER_DEBUG_KEYSTORE` selects a local standard Android debug keystore; otherwise Android Studio uses its default debug key. No signing key is included in this source archive.

This is a debug/test build, not a production release. To update an already installed APK, the app ID and signing certificate must match. For production, configure and securely retain your own release signing key.

## Testing

Stock flows, prior-invoice references, payment tracking, cash totals, the Balance box, cash out records, change-due review, the permission bridge, backup/restore, v4.0 and v4.1 data migration, mobile layouts and Android bridge behavior were tested in a browser. The Android project was compiled and its APK signature verified. This version has not been tested on a physical Android device in this environment; test it before relying on it for live inventory. Android System WebView should be up to date.
