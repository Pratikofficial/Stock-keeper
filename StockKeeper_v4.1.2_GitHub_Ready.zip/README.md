# StockKeeper v4.1.2 — Android Studio Project (2-Shop Edition)

StockKeeper is an offline inventory, sales, and cash flow manager designed for suppliers and stockists who sell to **2 Shops**.

## What's New in v4.1.2

* **Simple Dashboard**:
  - Direct **Cash in Hand (Available for Restock)** display showing exact cash balance available to restock items (`Opening Cash + Cash Collected from Shops − Cash Spent on Restock`).
  - **2 Shops Receivables Cards** (Shop 1 & Shop 2) with instant view of pending balances, total sales, and 1-tap "Settle Cash" buttons.
  - **Restock Priority Alerts** showing low/out-of-stock items, unit buy price, and estimated cash required to restock.
* **Fit-in-Screen Stock Out Page**:
  - Streamlined, unified layout designed to fit on a single mobile screen without endless scrolling.
  - Top shop switcher (`[ Shop 1 ]` / `[ Shop 2 ]`) instantly loads the selected shop's pending debt.
  - Compact quick-add bar with item dropdown, quantity, selling price, and quick-tap item chips.
  - Compact draft items table with inline edit and remove.
  - Compact billing card: Current items total, previous pending balance toggle (`☑️ Add previous pending to present invoice`), grand total, cash received input with quick buttons (`[ Full Cash ]`, `[ Items Only ]`, `[ Zero / Credit ]`), and dynamic balance status badge.
  - Prominent 1-click **Save Invoice & Update Stock** button.
* **Accurate Cash Flow & Restocking**:
  - Restocking items (Stock In) deducts purchase costs directly from Cash in Hand and increases stock.
  - Collecting cash on invoices or direct settlements immediately adds to Cash in Hand.
* **Direct Shop Cash Settlements**:
  - Collect payments directly from Shop 1 or Shop 2 when they pay their pending debt between sales.

## Building the Android APK

1. Open this project in **Android Studio** (Koala / Hedgehog or newer) with JDK 17+ and Android SDK 34.
2. Allow Gradle to sync.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run:
   ```bash
   ./gradlew assembleDebug
   ```
4. The generated APK will be in `app/build/outputs/apk/debug/app-debug.apk`.
