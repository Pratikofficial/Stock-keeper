package com.stockkeeper.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.Manifest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** A small offline WebView host with Android document pickers for backup and restore. */
public final class MainActivity extends Activity {
    private static final String APP_URL = "file:///android_asset/index.html";
    private static final int REQUEST_IMPORT = 1001;
    private static final int REQUEST_EXPORT = 1002;
    private static final int REQUEST_NOTIFICATIONS = 1003;
    private static final int MAX_EXPORT_CHARS = 30 * 1024 * 1024;
    private WebView webView;
    private ValueCallback<Uri[]> importCallback;
    private String pendingExport;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true); // required for bundled android_asset content
        settings.setAllowContentAccess(true); // required for the user-selected restore file
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setBlockNetworkLoads(true);
        webView.addJavascriptInterface(new LocalExportBridge(), "StockKeeperBridge");
        webView.addJavascriptInterface(new DeviceBridge(), "StockKeeperDevice");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                                       FileChooserParams params) {
                if (importCallback != null) importCallback.onReceiveValue(null);
                importCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES,
                        new String[]{"application/json", "text/plain", "application/octet-stream"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivityForResult(intent, REQUEST_IMPORT); }
                catch (ActivityNotFoundException e) {
                    importCallback.onReceiveValue(null);
                    importCallback = null;
                    message("No file picker is available on this device.");
                }
                return true;
            }
        });
        if (state == null || webView.restoreState(state) == null) webView.loadUrl(APP_URL);
    }

    /** Optional device bridge: permission requests and the backup reminder. Nothing is uploaded. */
    public final class DeviceBridge {
        @JavascriptInterface public boolean hasPermission(String name) {
            return "notifications".equals(name) && notificationsAllowed();
        }

        @JavascriptInterface public void requestPermission(final String name) {
            runOnUiThread(() -> {
                if (!"notifications".equals(name)) { reportPermission(name, false); return; }
                if (notificationsAllowed()) { reportPermission(name, true); return; }
                // Before Android 13 notifications need no runtime permission.
                if (Build.VERSION.SDK_INT < 33) { reportPermission(name, true); return; }
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_NOTIFICATIONS);
            });
        }

        @JavascriptInterface public void setReminder(boolean enabled) {
            BackupReminderReceiver.setReminder(MainActivity.this, enabled);
        }

        @JavascriptInterface public void postReminderNow() {
            BackupReminderReceiver.showNow(MainActivity.this);
        }
    }

    private boolean notificationsAllowed() {
        if (Build.VERSION.SDK_INT < 33) return true;
        return checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void reportPermission(String name, boolean granted) {
        final String script = "if (typeof onStockKeeperPermission === 'function') "
                + "{ onStockKeeperPermission('" + name.replace("'", "") + "', " + granted + "); }";
        runOnUiThread(() -> webView.evaluateJavascript(script, null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_NOTIFICATIONS) return;
        reportPermission("notifications",
                grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
    }

    /** The bridge accepts only local exports and delegates the destination to Android's picker. */
    public final class LocalExportBridge {
        @JavascriptInterface public void saveFile(String name, String mimeType, String contents) {
            if (contents == null || contents.length() > MAX_EXPORT_CHARS) {
                runOnUiThread(() -> message("Export is too large to save safely."));
                return;
            }
            final String safeName = name == null ? "stockkeeper-export.txt"
                    : name.replaceAll("[^A-Za-z0-9._-]", "_");
            final String mime = mimeType != null && mimeType.startsWith("application/json")
                    ? "application/json" : mimeType != null && mimeType.startsWith("text/csv")
                    ? "text/csv" : "text/plain";
            runOnUiThread(() -> {
                if (pendingExport != null) {
                    message("Finish the current save first.");
                    return;
                }
                pendingExport = contents;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try { startActivityForResult(intent, REQUEST_EXPORT); }
                catch (ActivityNotFoundException e) {
                    pendingExport = null;
                    message("No save-file picker is available on this device.");
                }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            if (importCallback != null) {
                Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
                importCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
                importCallback = null;
            }
        } else if (requestCode == REQUEST_EXPORT) {
            final String contents = pendingExport;
            pendingExport = null;
            final Uri uri = resultCode == RESULT_OK && data != null ? data.getData() : null;
            if (uri == null || contents == null) return;
            new Thread(() -> {
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "w")) {
                    if (stream == null) throw new IllegalStateException("Could not open the selected file");
                    stream.write(contents.getBytes(StandardCharsets.UTF_8));
                    stream.flush();
                    runOnUiThread(() -> message("File saved."));
                } catch (Exception e) {
                    runOnUiThread(() -> message("File could not be saved. Please try again."));
                }
            }, "stockkeeper-export").start();
        }
    }

    private void message(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        webView.evaluateJavascript("typeof handleAndroidBack === 'function' && handleAndroidBack()", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override protected void onDestroy() {
        if (importCallback != null) { importCallback.onReceiveValue(null); importCallback = null; }
        webView.removeJavascriptInterface("StockKeeperBridge");
        webView.destroy();
        super.onDestroy();
    }
}
