package com.stockkeeper.app;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.SystemClock;

/** Posts and schedules the optional on-device backup reminder. No data leaves the device. */
public final class BackupReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL_ID = "stockkeeper_backup";
    private static final int NOTIFICATION_ID = 4100;
    private static final long WEEK_MILLIS = 7L * 24L * 60L * 60L * 1000L;

    private static int immutableFlag() {
        return Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
    }

    private static PendingIntent reminderIntent(Context context) {
        Intent intent = new Intent(context, BackupReminderReceiver.class);
        return PendingIntent.getBroadcast(context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
    }

    /** Turns the weekly reminder on or off. The alarm is only a local notification timer. */
    static void setReminder(Context context, boolean enabled) {
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        PendingIntent pending = reminderIntent(context);
        if (enabled) {
            long first = System.currentTimeMillis() + WEEK_MILLIS;
            alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, WEEK_MILLIS, pending);
        } else {
            alarms.cancel(pending);
        }
    }

    /** Shows the reminder straight away, used by the test button in Settings. */
    static void showNow(Context context) {
        context.sendBroadcast(new Intent(context, BackupReminderReceiver.class));
    }

    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Backup reminders",
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Reminds you to export a StockKeeper backup.");
            manager.createNotificationChannel(channel);
        }
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return;

        Intent open = new Intent(context, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(context, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | immutableFlag());
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        Notification note = builder
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Back up your StockKeeper data")
                .setContentText("Your stock and invoices are stored only on this device. Export a backup.")
                .setContentIntent(content)
                .setAutoCancel(true)
                .build();
        manager.notify(NOTIFICATION_ID, note);
    }
}
